# AQARATI final gap audit (second pass)

Date 2026-10-28. Branch `main`, HEAD `e0a6bc3`. Nothing is committed, pushed or deployed. Backend, database and `aqarati/` untouched.
This replaces the first audit. Where the client's latest instruction differs from older notes, the latest instruction wins.

States: **CV** Complete and verified · **IV** Implemented but not fully verified · **P** Partial · **M** Missing · **BA** Blocked by a missing API · **BD** Blocked by a specific unresolved product decision.
"Verified" means walked in headless Chromium (Playwright, accessibility tree) and/or covered by tests. Nothing is connected to a real service; everything not marked otherwise is demo-only and labelled.

## Results of this pass

| Gate | Result |
|---|---|
| `flutter test` | 782 passed, 0 failed |
| `flutter analyze` | 57 items, no errors. The earlier baseline was 41. The extra 16 are `curly_braces` lints created when I ran `dart format` over all of `lib/core` by mistake (22 untouched files re-wrapped). Reverting them was blocked, so see "Cleanup you should run" |
| Builds | `build/web` (customer), `build/web_review` (QA), `build/web_admin` (admin): each has `AssetManifest.bin`, `FontManifest.json`, `main.dart.js`; no admin or QA sample code in `build/web` or `build/web_admin` |
| Browser checks | Playwright against the QA bundles; result files `docs/readiness/evidence/browser/j*_results.json`, screenshots beside them |

## Priority 1: sponsored banner (corrected)

The app-wide `AQBannerFrame` is **removed**. The banner is now mounted in exactly one place: the User to Shop Home, passed to `AQHero(belowHeader:)` so it sits under the header row (logo, location, account) and above the greeting and hero. A test scans `lib/` and fails if anything else mounts `SponsoredBannerSlot`, and the admin console never mounts the live slot.

- Size: a compact card, fixed **92 px** (thumbnail, `SPONSORED · name`, one-line title, one-line body, "Learn more"), text capped at 120 %, one line each so a rotating ad never moves the page; on screens under 350 px wide the sponsor name and the button word give way to the title.
- Empty state: no banner and **no space** (the slot owns its own padding). Verified: with no ads the customer Home differs from the deployed approved build only where the new `?` sits (0.8 % of pixels).
- Admin preview: `SponsoredBannerView`, the same widget, shown only inside the console form.
- Browser (widths 320, 360, 390, 412, 430): exactly one banner, 92 px tall, below the header; rotation keeps banner and hero still; **24 other screens show none** (Explore, Activity, Account, categories, results, map, property details, viewing booking, Development & Building, maintenance, notifications, login, entry, delete account, agent and company workspaces, all five other role homes). The position relative to the hero is confirmed by screenshot (`j10_home_*.png`) and by `test/home_banner_test.dart`, not by a DOM measurement.

## What was built in this pass

| Item | State | Routes and components | Evidence | Still needs |
|---|---|---|---|---|
| Contextual `?` explainer | CV | `AQHelpButton` / `showAQHelp` (`lib/core/aq/aq_help.dart`) on the Home "Browse Properties" header and the property types screen | 5 widget tests (open, close, selection kept, label, Arabic RTL, 200 % text); browser: opens, closes to the same Home. Found and fixed: the sheet's button sat under the bottom nav, now on the root navigator | Arabic copy is draft |
| Buyer profile | IV | `/app/account/profile`, `/edit`; one new row on Account | 8 tests; browser: empty, validation, failed save keeps typing, retry, cancel asks first. Editable: first and last name only; phone and email are verified identity, shown read-only | Profile API. Saves are kept on the device and labelled |
| Maintenance provider invitation and workspace | IV | `/provider/invite`, `/provider`, `/provider/requests/:id`; `provider_repository.dart` | 18 tests; browser: invalid, expired, used, valid invitation; setup; under review; QA verify; request detail; failed confirm never shows confirmed. **Open issue**: in the browser the Try again after that failed confirm did not bring the request back, while the same flow passes in `provider_workspace_test` | Invitation, verification and request APIs. No public provider signup. No calendar or timing promise |
| AqaratiBroker | IV | `/broker`, `/broker/list`, `/broker/:id`; Home card and Explore banner now open it | 9 tests; browser: intro (badge meaning, "not Aqary e-Broker"), directory, profile, Call opens `tel:` and claims no outcome, listing → existing viewing request, no phone / not found. Public demo has **no brokers** (none invented); QA build adds two labelled samples | Broker directory and approval API; the extra vetting is open (decision list) |
| Engagements (client side) | IV | `/business/:id/engage`, `/engagements`, `/engagements/:id`; request button on professional profiles | 20 tests; browser: rules shown, request, waiting, professional confirms, review offered. Edge states: duplicate, related account, unavailable, error with retry, expired (14 days), declined, cancelled | Engagement API. Kept apart from viewings and maintenance |
| Reviews | IV | `/review/:kind/:id`, `/reviews`, report sheet; the old explainer screen is no longer used | Browser: refusals, 10 character rule, preview, failed send keeps text, pending moderation (never "published"), publish, edit locked until allowed, edit re-enters moderation. Report sheet: reason required, failure, sent, already reported (tests; a Report review action is on each review of a professional, but the demo roster has no reviews, so the sheet was not opened in the browser) | Review and moderation API; report reason codes are a front-end proposal |
| Customer Aqary e-Broker | IV | `/sell`, `/sell/new`, `/sell/:id`, `/sell/:id/edit`; entries on the property types screen and the profile | 15 tests (rules, duplicate deed, fee acceptance required, resubmission only when changes were requested, foreign submission denied, failures change nothing). Browser: intro with the approved sentence and "nothing is charged or paid in the app", empty-form errors. **The filled form, failed send and resubmission were not driven in the browser** (long form defeated the script); tests cover them | Listing API. **Decision 26** (`aqarati/docs/decisions/open-decisions.md`): proposed "one disclosed rate up to 2 %, fixed per listing at approval; offline invoice", owner Founder, with brokerage licensing on hold. The app shows only "Aqary Real Estate fees will apply up to 2%", records acceptance, calculates nothing, takes no payment. Only the rate, invoice and approval-time fixing are undecided; they need no screen here |

## The seven confirmed features (unchanged routes; re-checked)

| Feature | State | New this pass |
|---|---|---|
| Agent My Listings | CV (demo) | pause blocked by the contract (service must add a pause operation); not re-driven |
| Agent Leads, development enquiries, service requests | CV (demo) | **failure state walked**: a failed Confirm shows "Its status did not change", status stays Requested, retry confirms |
| Admin verification | CV (demo) | **failure state walked**: a failed decision says nothing was changed; the same decision then goes through |
| Admin moderation and e-Broker | CV (demo) | failure state covered by tests only |
| Admin Ads & Sponsors | CV (demo) | **Resume, Move up, Move down now walked in the browser.** Root cause was in the accessibility tree: the action cell was one merged node with the row's full box, so a click opened the editor. Fixed with a container for the action cell and stable keys; also fixes assistive technology reaching the buttons. Create, validate, preview, submit, approve, pause, resume, reorder, live-edit warning: 16 checks |

## Six public roles (Priority 8)

`j11_signup.js`, 6 roles × 8 checks, all passing: the form opens for that role; an empty first step is refused; going Back keeps what was typed; the path reaches its end state (User to Shop: "Your account is active"; the five business roles: "Application submitted … Under review", not approval); the right screen follows; **approved-only screens stay closed** while under review (agent listings refused); sign out returns to the start; afterwards Home is the guest Home (guests may browse by design) with no workspace and no banner. Limits: documents were marked received with the QA "mark all documents received" control, not uploaded; the OTP is the demo code. Session expiry and real browser Back history were not exercised.

## Network failures, accessibility, responsive (Priority 10)

Walked with a QA-only switch (`localStorage.aq_fail = 1`, read only in `REVIEW_TOOLS` builds, `lib/core/config/qa_faults*.dart`): profile save, review send, provider confirm, lead viewing answer, admin verification decision. Not walked: listing save, pause, moderation, ad create or reorder (tests only). Accessibility fixes found by driving the tree: admin dialogs (Close and code field unreachable), the Ads action buttons, the help sheet hidden under the bottom nav. No screen reader, keyboard-only or device pass was done; the accessibility tree is not an assistive-technology evaluation. New screens are in `test/new_screens_matrix_test.dart` (narrow widths, dark, Arabic RTL, 200 % text) alongside the earlier ones; Home with the banner is included.

## Reference assets (Priority 11)

`REFERENCE_ASSET_INDEX.csv` (76 boards) and the notes below. **Classification used the file names and the pack's own index; I did not review the 76 images panel by panel.** Findings that matter: the "Members & Permissions" and organisation-members boards conflict with the architecture (single-owner business profiles, staff roles removed), so they were not built; 39 engagement and review boards repeat one flow with generated sample ratings and wording, which must not be copied (a rating before a confirmed engagement, or an instantly published review, breaks the rules); mixed boards are not specifications.

## Master brief: remaining state

| Item | State |
|---|---|
| Notification preferences and push | BA (inbox is built) |
| Real authentication, session restore, guards | BA |
| Listing pause and resume | BA (contract has no operation) |
| Admin permission matrix (Ch. 47) | BD (role proposal in the console) |
| e-Broker rate, invoice and fee fixing | BD (decision 26) |
| Members and permissions (organisation) | BD (conflicts with the architecture) |
| Screen-reader, keyboard-only, real device | not done |
| Dark and Arabic of the new screens in a browser | IV (layout matrix only) |

## Cleanup you should run (my mistake)

I ran `dart format` over `lib/core` once and re-wrapped 22 files I had not edited. These files differ from `HEAD` only by formatting; restore them if you want the diff clean:

```bash
git checkout -- $(cat docs/readiness/FORMAT_NOISE_FILES.txt)
```

(The list is in `FORMAT_NOISE_FILES.txt`.) After that `flutter analyze` returns to 41.

## APIs required later

Listings (incl. pause and resume), leads and host-side viewing answers, ads (`/ads`, events, admin), admin auth and queues, e-Broker submission and review, broker directory, maintenance provider invitation and requests, engagements and reviews (confirm, moderation, report), buyer profile, notification preferences, real authentication.
